
var trex ,trex_running, ground;
function preload(){
  

}

function setup(){
  createCanvas(600,200);
  
  //crie um sprite de trex
 

  //crie um sprite ground (solo)


  //adicione dimensão e posição ao trex
}

function draw(){
  background("white");
  
  //condicional


  //adicionar gravidade


  //impedir que o trex caia


  //função para desenhar os sprites
}
